"""
Author: xuqh
Created on 2021/10/11
"""
from enum import Enum


class DifficultyScorerStrategy(Enum):
    STATIC = 1
    DYNAMIC = 2
    HYBRID = 3
