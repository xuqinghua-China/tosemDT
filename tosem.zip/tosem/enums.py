
from enum import Enum


class DifficultyScorerStrategy(Enum):
    STATIC = 1
    DYNAMIC = 2
    HYBRID = 3
