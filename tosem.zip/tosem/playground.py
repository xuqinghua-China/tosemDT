"""
Author: xuqh
Created on 2020/11/20
"""


def minVb(n, k, nums, delFromMax=True):
    if k == 0:
        if n == 0:
            return 0
        else:
            v = [0]
            for i in range(1, n):
                v.append(abs(nums[i] - nums[i - 1]))
            return max(v)
    else:
        if delFromMax:
            selected = max(nums)
        else:
            selected = min(nums)
        idx = nums.index(selected)
        del nums[idx]
        return minVb(n - 1, k - 1, nums)


def get_result(n, k, nums):
    return min(minVb(n, k, nums.copy(), delFromMax=True), minVb(n, k, nums.copy(), delFromMax=False))


if __name__ == '__main__':
    n = 6
    k = 3
    nums = [1, 2, 3, 7, 8, 9]
    print(get_result(n, 3, nums))
